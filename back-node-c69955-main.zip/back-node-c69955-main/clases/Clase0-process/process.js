// console.log(process.cwd())
// console.log(process.pid)
// console.log(process.memoryUsage())
// console.log(process.version)
// console.log(process.env)


// argumentos
// node process.js 1 2 3 
console.log(process.argv)